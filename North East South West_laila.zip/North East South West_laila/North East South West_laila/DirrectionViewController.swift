//
//  DirrectionViewController.swift
//  North East South West_laila
//
//  Created by administrator on 12/12/2021.
//

import UIKit

class DirrectionViewController: UIViewController {

    @IBOutlet var ResultButton: UIButton!
    
    var dirrection: String?
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        ResultButton.setTitle(dirrection, for: .normal)
        ResultButton.titleLabel?.font = UIFont(name: "HelveticaNeue-Thin", size: 55)
        
    }

}
