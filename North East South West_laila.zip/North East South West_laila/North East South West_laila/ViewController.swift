//
//  ViewController.swift
//  North East South West_laila
//
//  Created by administrator on 12/12/2021.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let dirrection = sender as! String
        let destination = segue.destination as! DirrectionViewController
        
        destination.dirrection = dirrection
        
    }

    @IBAction func DirrectionButtons(_ sender: UIButton) {
        
        performSegue(withIdentifier: "DirrectionSegue", sender: sender.titleLabel!.text!)
    }
    
    @IBAction func BackMain(_ sege: UIStoryboardSegue){
        
    }
    
}

